"""Allow running AgentOS as: python -m agentos"""

from agentos.cli import main

if __name__ == "__main__":
    main()